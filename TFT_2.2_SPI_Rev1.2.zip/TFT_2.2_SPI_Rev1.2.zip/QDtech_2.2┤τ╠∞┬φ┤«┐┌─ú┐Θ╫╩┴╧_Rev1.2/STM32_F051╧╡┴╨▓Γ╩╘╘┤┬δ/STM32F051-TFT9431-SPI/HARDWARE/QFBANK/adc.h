#ifndef __ADC_H
#define	__ADC_H

#include "stm32f0xx.h"

void ADC1_DMA_Init(void);

#endif /* __ADC_H */
