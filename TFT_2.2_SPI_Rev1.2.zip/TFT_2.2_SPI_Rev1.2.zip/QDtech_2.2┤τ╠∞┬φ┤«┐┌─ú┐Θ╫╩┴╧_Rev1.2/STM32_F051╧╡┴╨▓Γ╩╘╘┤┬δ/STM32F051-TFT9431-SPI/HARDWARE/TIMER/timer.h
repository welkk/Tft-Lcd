#ifndef _TIME_H_
#define _TIME_H_

void TIM14_Init(u16 arr,u16 psc);

#endif  /* _TIME_H_ */
